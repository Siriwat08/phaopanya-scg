# LMDS Supreme AI Engineer — Single Skill

All-in-one consolidated LMDS skills suite. 11 specialties → 1 file.

## How to install

### Mavis cloud runtime (`/workspace/.skills/`)
```bash
unzip -j lmds-skills-suite.zip 'lmds-supreme-engineer/SKILL.md' \
  -d /workspace/.skills/lmds-supreme-engineer/SKILL.md
```

### Local mavis install
```bash
unzip lmds-skills-suite.zip
mkdir -p ~/.mavis/skills/lmds-supreme-engineer
cp lmds-supreme-engineer/SKILL.md ~/.mavis/skills/lmds-supreme-engineer/
# restart mavis daemon
```

## File structure (matches upload-system requirement)
```
lmds-supreme-engineer/
└── SKILL.md    (≈200KB, all 11 specialties merged)
```

## Sections inside
- §0 Orchestrator Role & Routing
- §1 Architecture · §2 Bug Hunter · §3 CI/CD · §4 Code Reviewer
- §5 GAS Best Practices · §6 Match Engine · §7 Pre-Deploy
- §8 Refactor Advisor · §9 Security Auditor · §10 Thai Data Helper
- §11 Original Orchestrator Body
