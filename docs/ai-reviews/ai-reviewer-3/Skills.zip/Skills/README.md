# LMDS V6.0 Skills — Complete Suite

> **สร้างจากโปรเจกต์:** [`phaopanya-scg`](https://github.com/Siriwat08/phaopanya-scg) (LMDS V6.0.044)
> **วันที่สร้าง:** 2026-07-13
> **จำนวน Skills:** 10 (ครอบคลุมทุกมิติของโปรเจกต์)

ชุด Skills นี้ออกแบบมาเพื่อช่วย AI Agent (Mavis) และนักพัฒนาในการทำงานกับโปรเจกต์ **LMDS (Logistics Master Data System) V6.0** — ระบบจัดการข้อมูลหลักด้านการขนส่งที่พัฒนาบน **Google Apps Script + Google Sheets** สำหรับ SCG JWD Logistics

---

## 🎯 ภาพรวม Skills ทั้ง 10

| # | Skill | Purpose | ใช้เมื่อ... |
|---|---|---|---|
| 1 | **`lmds-architect`** | Master architecture overview | ต้องการเข้าใจโครงสร้างโปรเจกต์, 3-Domain Groups, 16 Laws, 8 Rules, 35 .gs files, Sheet schema |
| 2 | **`lmds-code-reviewer`** | 16 Immutable Laws enforcement | Review code, audit PR, enforce SRP / No Hardcode Index / Batch Operations / Security-First |
| 3 | **`lmds-bug-hunter`** | BUGHUNT scanner (Critical + Performance) | หา bugs / critical issues / timeout / stale cache / scientific notation |
| 4 | **`lmds-refactor-advisor`** | Refactor planning (SRP, complexity, length) | แตก god function, ลด coupling, plan major refactor |
| 5 | **`lmds-predeploy-checker`** | Production go/no-go gate | ก่อน deploy, ตรวจ 35-item checklist, verify version sync |
| 6 | **`lmds-match-engine-builder`** | Trinity + 8 Rules + Hybrid Alias | สร้าง/แก้ match logic, เพิ่ม rule ใหม่, debug matching |
| 7 | **`lmds-gas-best-practices`** | GAS limitations & workarounds | 6-min limit, CacheService 100KB, LockService, custom function, clasp |
| 8 | **`lmds-cicd-pipeline`** | GitHub Actions for clasp | ตั้ง CI/CD, แก้ deploy fail, เพิ่ม workflow, secret management |
| 9 | **`lmds-security-auditor`** | SEC-001 → SEC-012 (12 fixes) | Security review, hardcoded secret, PII leak, OAuth scope, sheet protection |
| 10 | **`lmds-thai-data-helper`** | Thai name/address/phonetic/geo | Thai prefix stripping, phone normalization, Double Metaphone, Thai geo lookup |

---

## 🗺️ Decision Tree — เลือก Skill ที่ถูกต้อง

```
❓ คำถามของผู้ใช้
│
├─ "โปรเจกต์นี้คืออะไร / ทำอะไรได้ / โครงสร้างเป็นยังไง"
│  └─> lmds-architect ✅ (load อันนี้ก่อนเสมอ)
│
├─ "โค้ดนี้ผ่าน 16 Laws ไหม / review code"
│  └─> lmds-code-reviewer ✅
│
├─ "หา bug / critical issue / performance / timeout"
│  └─> lmds-bug-hunter ✅
│
├─ "function นี้ยาวเกินไป / แตก god function ยังไง"
│  └─> lmds-refactor-advisor ✅
│
├─ "พร้อม deploy หรือยัง / pre-deploy check"
│  └─> lmds-predeploy-checker ✅
│
├─ "เพิ่ม match rule ใหม่ / แก้ 8-rule / Trinity / Alias"
│  └─> lmds-match-engine-builder ✅
│
├─ "GAS limit / CacheService / LockService / clasp / custom function"
│  └─> lmds-gas-best-practices ✅
│
├─ "GitHub Actions / clasp push fail / workflow / deploy"
│  └─> lmds-cicd-pipeline ✅
│
├─ "security audit / SEC-001 → SEC-012 / PII / secret"
│  └─> lmds-security-auditor ✅
│
└─ "Thai name / Thai address / phonetic / postal code"
   └─> lmds-thai-data-helper ✅
```

---

## 📦 ข้อมูลโปรเจกต์อ้างอิง

| Field | Value |
|---|---|
| **System** | LMDS (Logistics Master Data System) |
| **Version** | 6.0.044 (Production Ready, 96%) |
| **Platform** | Google Apps Script V8 + Google Sheets |
| **Domain** | SCG JWD Logistics (Thailand) |
| **Code Stats** | 35 .gs files (34 prod + 1 legacy) + 19 .html files = ~27,213 lines, 535 functions |
| **Compliance** | 16/16 Immutable Laws + 5/5 Hard Rules = 100% |
| **Security** | 12/12 SEC checks (SEC-001 → SEC-012) |
| **Quality** | 18 audit cycles complete, 116 issues fixed |
| **OAuth Scopes** | 6 (Least Privilege) |
| **CI/CD** | 8 GitHub Actions workflows |
| **Repo** | https://github.com/Siriwat08/phaopanya-scg |
| **License** | MIT |

---

## 🔄 Dependency Chain

```
                    ┌──────────────────┐
                    │  lmds-architect  │  ← เริ่มที่นี่
                    │  (Master)        │
                    └────────┬─────────┘
                             │
       ┌─────────────────────┼─────────────────────┐
       │                     │                     │
       ▼                     ▼                     ▼
┌──────────────┐    ┌──────────────┐      ┌──────────────────┐
│ code-reviewer│    │  bug-hunter  │      │  gas-best-       │
│              │    │              │      │  practices       │
└──────┬───────┘    └──────┬───────┘      └──────────────────┘
       │                   │
       └──────┬────────────┘
              │
       ┌──────▼──────┐         ┌──────────────────┐
       │ refactor-   │         │ security-        │
       │ advisor     │         │ auditor          │
       └──────┬──────┘         └──────┬───────────┘
              │                       │
              └──────────┬────────────┘
                         │
                  ┌──────▼──────┐
                  │ predeploy-  │  ← ก่อน deploy เสมอ
                  │ checker     │
                  └──────┬──────┘
                         │
                  ┌──────▼──────┐
                  │   cicd-     │  ← deploy & release
                  │   pipeline  │
                  └─────────────┘

       ┌─────────────────────┐         ┌──────────────────┐
       │ match-engine-       │◄────────┤  thai-data-      │
       │ builder             │         │  helper          │
       └─────────────────────┘         └──────────────────┘
```

---

## 🧪 Quick Examples

### Example 1: Review new code

```
User: "review this code" + pastes function
→ Mavis loads: lmds-architect (context)
→ Mavis loads: lmds-code-reviewer (apply 16 Laws)
→ If bugs found: lmds-bug-hunter
→ Output: Compliance matrix + patches
```

### Example 2: Pre-deploy check

```
User: "พร้อม deploy ไหม?"
→ Mavis loads: lmds-architect (know project)
→ Mavis loads: lmds-code-reviewer (verify laws)
→ Mavis loads: lmds-bug-hunter (find P0)
→ Mavis loads: lmds-security-auditor (SEC-001→012)
→ Mavis loads: lmds-predeploy-checker (final gate)
→ Output: GO / NO-GO with score
```

### Example 3: Add new match rule

```
User: "ผมอยากเพิ่ม Rule 9: VIP customer override"
→ Mavis loads: lmds-architect (know file structure)
→ Mavis loads: lmds-match-engine-builder (how to add rule)
→ Mavis loads: lmds-code-reviewer (verify code quality)
→ Output: New MATCH_RULES entry + decide function + tests
```

### Example 4: Debug "pipeline timeout"

```
User: "pipeline หยุดกลางทางทุกที"
→ Mavis loads: lmds-architect (know Match Engine)
→ Mavis loads: lmds-gas-best-practices (6-min limit)
→ Mavis loads: lmds-bug-hunter (P1 patterns)
→ Output: Add Time Guard + Checkpoint + Auto-Resume pattern
```

---

## 📊 Skill Coverage Matrix

| หัวข้อ | Architect | Reviewer | Bug-Hunt | Refactor | PreDeploy | Match | GAS | CI/CD | Security | Thai |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **Architecture** | ✅ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ |
| **16 Laws** | ⚪ | ✅ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ |
| **Critical bugs** | ⚪ | ⚪ | ✅ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ |
| **Refactor planning** | ⚪ | ⚪ | ⚪ | ✅ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ |
| **Deploy gate** | ⚪ | ⚪ | ⚪ | ⚪ | ✅ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ |
| **Match engine** | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ✅ | ⚪ | ⚪ | ⚪ | ⚪ |
| **GAS limits** | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ✅ | ⚪ | ⚪ | ⚪ |
| **CI/CD** | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ✅ | ⚪ | ⚪ |
| **SEC-001→012** | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ✅ | ⚪ |
| **Thai data** | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ⚪ | ✅ |

Legend: ✅ Primary owner | ⚪ Not the main focus

---

## 🛠️ โครงสร้างไฟล์

```
/workspace/.skills/
├── README.md                              # ไฟล์นี้
├── lmds-architect/
│   └── SKILL.md                          # 27,774 bytes — Master overview
├── lmds-code-reviewer/
│   └── SKILL.md                          # 21,522 bytes — 16 Laws enforcement
├── lmds-bug-hunter/
│   └── SKILL.md                          # 19,117 bytes — BUGHUNT scanner
├── lmds-refactor-advisor/
│   └── SKILL.md                          # 16,562 bytes — Refactor planning
├── lmds-predeploy-checker/
│   └── SKILL.md                          # 12,545 bytes — Pre-deploy gate
├── lmds-match-engine-builder/
│   └── SKILL.md                          # 19,341 bytes — 8 Rules + Trinity
├── lmds-gas-best-practices/
│   └── SKILL.md                          # 19,305 bytes — GAS limitations
├── lmds-cicd-pipeline/
│   └── SKILL.md                          # 15,619 bytes — GitHub Actions
├── lmds-security-auditor/
│   └── SKILL.md                          # 21,661 bytes — SEC-001→012
└── lmds-thai-data-helper/
    └── SKILL.md                          # 21,180 bytes — Thai data
```

**Total:** 10 SKILL.md files | ~194 KB | 16 Immutable Laws covered | 12 Security checks covered | 8 GitHub Actions workflows documented

---

## 🎓 Learning Path

ถ้าคุณเพิ่งเข้ามาทำงานกับ LMDS แนะนำให้อ่านตามลำดับนี้:

1. **`lmds-architect`** — เข้าใจโครงสร้างก่อน (30 นาที)
2. **`lmds-code-reviewer`** — เรียนรู้กฎ 16 ข้อ (45 นาที)
3. **`lmds-gas-best-practices`** — เข้าใจข้อจำกัด GAS (20 นาที)
4. **`lmds-match-engine-builder`** — เข้าใจหัวใจของระบบ (30 นาที)
5. **`lmds-thai-data-helper`** — เรียนรู้ Thai normalization (20 นาที)
6. **`lmds-bug-hunter`** — เรียนรู้ historical bugs (30 นาที)
7. **`lmds-security-auditor`** — เรียนรู้ SEC checklist (30 นาที)
8. **`lmds-refactor-advisor`** — เรียนรู้ SRP (15 นาที)
9. **`lmds-cicd-pipeline`** — เข้าใจ CI/CD (20 นาที)
10. **`lmds-predeploy-checker`** — เรียนรู้ production gate (15 นาที)

**รวม: ~4 ชั่วโมง** จะเข้าใจ LMDS ครบทุกมิติ

---

## 📞 เอกสารอ้างอิงจาก Repo ต้นฉบับ

ทั้งหมดนี้สกัดมาจากเอกสารจริงใน [phaopanya-scg](https://github.com/Siriwat08/phaopanya-scg):

- `README.md` — Quick start
- `CONTEXT.md` — Code conventions
- `BLUEPRINT.md` — Full architecture
- `LMDS Supreme Engineer.md` — AI system prompt
- `CONTRIBUTING.md` — Git workflow
- `SECURITY.md` — Vulnerability policy
- `docs/01_SOP_Admin_LMDS.md` — Admin SOP (Thai)
- `docs/02_IT_Guide_LMDS.md` — IT guide (Thai)
- `docs/03_Executive_Summary_LMDS.md` — Exec summary
- `docs/04_WebApp_Guide.md` — WebApp usage
- `docs/01-github-actions-overview.md` — CI/CD guide
- 8 `.github/workflows/*.yml` files
- 9 `.github/scripts/doc-code-sync-checks/*.sh` files

---

**Maintained by:** Mavis (MiniMax-M3)
**Last sync:** 2026-07-13
**Source:** https://github.com/Siriwat08/phaopanya-scg @ V6.0.044
