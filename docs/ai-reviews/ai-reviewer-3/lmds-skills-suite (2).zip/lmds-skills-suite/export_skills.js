const fs = require('fs');
const path = require('path');

const baseDir = __dirname;
const srcDir = path.join(baseDir, '.skills');
const destDir = path.join(baseDir, 'exports');

// Create directories
const dirs = [
    'gemini/gemini_individual',
    'claude/claude_individual',
    'universal/skills'
];

dirs.forEach(d => {
    fs.mkdirSync(path.join(destDir, d), { recursive: true });
});

function extractSkill(content) {
    const match = content.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n([\s\S]*)$/);
    if (match) {
        const yaml = match[1];
        let body = match[2].trim();
        
        let name = 'unknown';
        let desc = '';
        const nameMatch = yaml.match(/name:\s*(.+)/);
        if (nameMatch) name = nameMatch[1].trim();
        
        const descMatch = yaml.match(/description:\s*([\s\S]*)/);
        if (descMatch) desc = descMatch[1].replace(/\r?\n/g, ' ').trim();
        
        return { name, description: desc, body };
    }
    return null;
}

const skills = [];
const items = fs.readdirSync(srcDir);

for (const item of items) {
    const skillDir = path.join(srcDir, item);
    if (fs.statSync(skillDir).isDirectory()) {
        const skillPath = path.join(skillDir, 'SKILL.md');
        if (fs.existsSync(skillPath)) {
            let content = fs.readFileSync(skillPath, 'utf8');
            
            // Clean up specific known issues
            if (item === 'lmds-refactor-advisor') {
                content = content.replace(/Integration(\r?\n)+This skill works best when.*if the refa.*$/i, 'Integration\n\nThis skill works best when combined with `lmds-architect` and `lmds-code-reviewer`.');
                // Alternatively, just fix the truncation at the end
                if (content.endsWith('if the refa')) {
                    content = content.replace(/if the refa$/, 'if the refactoring targets are critical path. Always run `lmds-bug-hunter` after splitting functions.');
                }
            }
            if (item === 'lmds-thai-data-helper') {
                content = content.replace(/Excellent! All 10 skills are done.*/ig, '');
            }

            const extracted = extractSkill(content);
            if (extracted) {
                skills.push(extracted);
                
                // Gemini .txt (plain text format)
                fs.writeFileSync(path.join(destDir, 'gemini', 'gemini_individual', `${extracted.name}.txt`), extracted.body);
                
                // Claude .md (markdown format)
                fs.writeFileSync(path.join(destDir, 'claude', 'claude_individual', `${extracted.name}.md`), `# ${extracted.name}\n\n${extracted.body}`);
                
                // Universal .md
                fs.writeFileSync(path.join(destDir, 'universal', 'skills', `${extracted.name}.md`), `# ${extracted.name}\n\n${extracted.body}`);
            }
        }
    }
}

// Configs
const geminiConfig = {
    model: "gemini-2.5-pro",
    system_instruction: "You are Mavis, the LMDS V6.0 AI Agent. Use the available skills to answer the user.",
    skills: skills.map(s => ({
        name: s.name,
        description: s.description,
        system_instruction: s.body
    }))
};
fs.writeFileSync(path.join(destDir, 'gemini', 'gemini_skills_config.json'), JSON.stringify(geminiConfig, null, 2));

const claudeConfig = {
    model: "claude-3-5-sonnet-20241022",
    system: "You are Mavis, the LMDS V6.0 AI Agent. Use the available skills to answer the user.",
    skills: skills.map(s => ({
        name: s.name,
        description: s.description,
        content: s.body
    }))
};
fs.writeFileSync(path.join(destDir, 'claude', 'claude_skills_config.json'), JSON.stringify(claudeConfig, null, 2));

// Master Prompts with Decision Tree
const decisionTree = `## 🗺️ Decision Tree — ระบบวิเคราะห์คำสั่ง (ให้ AI ประเมินและเลือก Skill)
เมื่อผู้ใช้ถามคำถาม ให้พิจารณาโหลดข้อมูลจาก Skill ที่ตรงกับบริบทมากที่สุด:
- หากถามเกี่ยวกับ โครงสร้าง/ภาพรวม/ไฟล์ต่างๆ -> ใช้ \`lmds-architect\`
- หากสั่งให้ review code หรือตรวจสอบ compliance -> ใช้ \`lmds-code-reviewer\`
- หากต้องการหา bug/critical issue -> ใช้ \`lmds-bug-hunter\`
- หากฟังก์ชันยาวเกินไป ต้องการ refactor -> ใช้ \`lmds-refactor-advisor\`
- หากต้องการเช็คก่อน deploy ขึ้น production -> ใช้ \`lmds-predeploy-checker\`
- หากเกี่ยวข้องกับ Match Engine / 8 Rules / Trinity -> ใช้ \`lmds-match-engine-builder\`
- หากติดปัญหา GAS timeout / Quota / CacheService -> ใช้ \`lmds-gas-best-practices\`
- หากเกี่ยวกับ CI/CD / GitHub Actions / Deploy -> ใช้ \`lmds-cicd-pipeline\`
- หากเกี่ยวกับ Security / PII / API keys -> ใช้ \`lmds-security-auditor\`
- หากเกี่ยวกับ ข้อมูลภาษาไทย / ที่อยู่ / ชื่อ / เบอร์โทร -> ใช้ \`lmds-thai-data-helper\`
`;

let masterPrompt = `You are Mavis, the AI Agent for LMDS V6.0 (Logistics Master Data System).\n\n${decisionTree}\n\n## Available Skills\n\n`;
skills.forEach(s => {
    masterPrompt += `### SKILL: ${s.name}\n${s.body}\n\n=================================\n\n`;
});

fs.writeFileSync(path.join(destDir, 'gemini', 'gemini_master_prompt.txt'), masterPrompt);
fs.writeFileSync(path.join(destDir, 'claude', 'claude_master_prompt.md'), masterPrompt);

// YAML registry
let yamlContent = `version: "1.0"\nproject: LMDS V6.0\nskills:\n`;
skills.forEach(s => {
    yamlContent += `  - name: ${s.name}\n    description: "${s.description.replace(/"/g, '\\"')}"\n    file: skills/${s.name}.md\n`;
});
fs.writeFileSync(path.join(destDir, 'universal', 'skills_registry.yaml'), yamlContent);

// README
const readme = `# LMDS Skills Export

โฟลเดอร์นี้รวบรวมไฟล์ Export ของ LMDS Skills ทั้ง 10 ตัว สำหรับนำไปใช้งานกับ AI platforms ต่างๆ อย่างสมบูรณ์แบบ
*อัปเดตล่าสุดจากการแปลงไฟล์ SKILL.md ดั้งเดิม*

## 📂 โครงสร้างและวิธีใช้งาน

### 1. Google Gemini (โฟลเดอร์ \`gemini/\`)
- **\`gemini_individual/\`**: (แนะนำ) นำไฟล์ \`.txt\` แต่ละอันไปใส่เป็น System Instructions แยกกันใน Google AI Studio เพื่อไม่ให้กิน Context เปล่าๆ ในเรื่องที่ไม่เกี่ยวข้อง
- **\`gemini_master_prompt.txt\`**: รวมทุก skill ไว้ในไฟล์เดียว พร้อม **Decision Tree** นำไปแปะใน System Instructions หรือ Prompt ครั้งเดียวจบ (เหมาะสำหรับ Gemini 1.5/2.0 ที่รองรับ Context ได้ 1M-2M tokens)
- **\`gemini_skills_config.json\`**: สำหรับนักพัฒนาที่ต้องการนำไปใช้เรียกผ่าน Gemini API

### 2. Claude - Anthropic (โฟลเดอร์ \`claude/\`)
- **\`claude_individual/\`**: (แนะนำ) นำไฟล์ \`.md\` ไปอัปโหลดเข้า **Claude Projects** ในส่วนของ Project Knowledge
- **\`claude_master_prompt.md\`**: รวมทุก skill ไว้ในไฟล์เดียว นำไปแปะเป็น Custom Instructions (System Prompt) ของ Claude 
- **\`claude_skills_config.json\`**: สำหรับการเรียกใช้งานผ่าน Claude API แบบมีโครงสร้าง

### 3. Universal (โฟลเดอร์ \`universal/\`)
- **\`skills/\`**: ไฟล์ markdown สะอาด (ตัด YAML header ออกแล้ว) เหมาะสำหรับนำไปใช้อ้างอิงกับ AI Editor เช่น Cursor, Windsurf หรือ GitHub Copilot
- **\`skills_registry.yaml\`**: ไฟล์สารบัญ (Metadata) ของระบบ สำหรับการสร้าง custom loader

## 🛠️ การปรับปรุงที่ทำในเวอร์ชันนี้
1. ตัด YAML frontmatter ออกจากเนื้อหาหลัก เพื่อไม่ให้รบกวน AI Prompting
2. เพิ่ม Decision Tree อัตโนมัติใน Master Prompt เพื่อให้ AI รู้ว่าควรดึง Skill ไหนมาใช้เมื่อใด
3. แก้ไขบั๊กเนื้อหาที่ขาดหายใน \`lmds-refactor-advisor\` และเคลียร์ข้อความส่วนเกินใน \`lmds-thai-data-helper\`
`;
fs.writeFileSync(path.join(destDir, 'README.md'), readme);

console.log("SUCCESS: Exported " + skills.length + " skills to " + destDir);
